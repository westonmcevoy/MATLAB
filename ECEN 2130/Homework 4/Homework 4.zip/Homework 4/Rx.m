function R = Rx(al)
% Description line 1
% Description line 2

% Generic comment

R = [1    0       0;
     0 cos(al) -sin(al);
     0 sin(al) cos(al)];
end

