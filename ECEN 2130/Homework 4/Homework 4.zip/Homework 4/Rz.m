function R = Rz(al)
R = [cos(al) -sin(al) 0;
     sin(al) cos(al)  0;
       0        0     1;];
end

