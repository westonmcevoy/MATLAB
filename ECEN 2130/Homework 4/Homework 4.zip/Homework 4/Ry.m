function R = Ry(al)

R = [cos(al) 0  sin(al)
       0     1    0
    -sin(al) 0  cos(al)];
end

